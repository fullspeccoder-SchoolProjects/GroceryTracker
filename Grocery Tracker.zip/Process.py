import re
import string
import sys

def printsomething():
    print("Hello World")

# CalculateItemCounts

# Description:
#     Calculates All Item counts of file
# Example:
#     itemCounts = CalculateItemCounts(file_name)
# Returns:
#     List of calculated items

# FUNCTION DisplayItemCounts(word file_name)
def DisplayItemCounts():
    
    my_file = open('U:\\"Grocery Tracker"\Release\\CS_210_Input_File.txt', 'r')
    
    items = my_file.read().split('\n')[:]
    item_names = set(items)
    
    for item in items:
#       Checks if item name is a space and removes it
        if item in ' ':
            item_names.remove(item)
            
        if item in item_names:
            print(item + ": " + items.count(item))
            item_names.remove(item)
            
    my_file.close()

# Calculate Item Count

# Description:
#     Calculates All Item counts of file
# Example:
#     itemCounts = CalculateItemCounts(file_name)
# Returns:
#     List of calculated items

# CalculateItemCount(word item_name)
def CalculateItemCount(item_name):
    
    my_file = open('CS_210_Input_File.txt', 'r')
    
    items = my_file.read().split('\n')
    
    my_file.close()
    
    return items.count(item_name)

# CreateFile

# Description:
#     Creates file with records of all item and their counts
# Example:
#     itemCounts = CreateFile()
# Returns:
#     None

# FUNCTION CreateFile()
def CreateFile():
        # print(file_name[:-4] + '.dat')
    try:
        my_file = open('CS_210_Input_File.txt', 'r')
        new_file = open('CS_210_Input_File.dat', 'w')
        
        items = my_file.read().split('\n')
        item_names = set(items)
        print(item_names)
        
        for item in item_names:
    #       Checks if item name is a space and removes it
            if item in items:
                new_file.write(f'{item} {items.count(item)}\n')
                
        my_file.close()
        new_file.close()
    except OSError:
        print("Could Not Read File")
