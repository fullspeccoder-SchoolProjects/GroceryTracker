#include <Python.h>
#include <Windows.h>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <cmath>
#include <string>

using namespace std;

void displayBanner(string title, int width = 40) {
	int sideWidth = (width - title.length()) / 2;

	// Creates a banner based on parameters
	cout << right << setw(width) << setfill('=');
	cout << " " << endl;
	cout << setw(sideWidth) << setfill(' ') << " ";
	cout << title;
	cout << setw(sideWidth) << setfill(' ') << left << " " << endl;
	cout << right << setw(width) << setfill('=') << " ";
	cout << "\n" << endl;

	// Resets output stream manipulators
	cout << left;
	cout << setfill(' ');
}

/*
Description:
	To call this function, simply pass the function name in Python that you wish to call.
Example:
	callProcedure("printsomething");
Output:
	Python will print on the screen: Hello from python!
Return:
	None
*/
void callProcedure(string pName)
{
	char* procname = new char[pName.length() + 1];
	std::strcpy(procname, pName.c_str());

	Py_Initialize();
	PyObject* my_module = PyImport_ImportModule("Process");
	PyErr_Print();
	PyObject* my_function = PyObject_GetAttrString(my_module, procname);
	PyObject* my_result = PyObject_CallObject(my_function, NULL);
	Py_Finalize();

	delete[] procname;
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("PrintMe","Test");
Output:
	Python will print on the screen:
		You sent me: Test
Return:
	100 is returned to the C++
*/
int callIntFunc(string proc, string param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	char* paramval = new char[param.length() + 1];
	std::strcpy(paramval, param.c_str());


	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"Process");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(z)", paramval);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;
	delete[] paramval;


	return _PyLong_AsInt(presult);
}


//	Displays menu for the tracking program; Is used in the main loop of the program
void displayMenu() {

	displayBanner("Grocery Tracker Program");

	// Menu Options
    cout << "1: Display Inventory Sold" << endl;
    cout << "2: Item Inquiry" << endl;
    cout << "3: Display Histogram Of Items Sold" << endl;
    cout << "4: Exit Program\n" << endl;

	// Resets filling to space
    cout << setfill(' ');
}

// Checks each character in a string if it is a digit
bool checkString(char input[]) {
    bool digitInString = 0;
    size_t i;

    for (i = 0; i < strlen(input); ++i) {
		digitInString = isdigit(input[i]);
		if (digitInString) {
			return digitInString;
		}
    }

    return digitInString;
}

// Validates user input's string to make sure it is not a number, and that there is no number in the string
string validateUserString() {
    char userInput[50];

	// This will keep asking for valid input until met
    cin >> userInput;
    while (checkString(userInput)) {

        cout << "Enter an item name" << endl;

        cin.clear();

        cin.ignore(123, '\n');

        cin >> userInput;
    }

    return userInput;
}

// Validates input until an integer has been typed in
int validateUserInt() {
    int userInput;

    while (!(cin >> userInput)) {
        cout << "Enter a selection" << endl;

        cin.clear();

        cin.ignore(123, '\n');
    }

    return userInput;
}

// Creates a line of characters for n number of times
void nCharString(char character, int n) {
    int i;

    for (i = 0; i < n; i++) {
        cout << character;
    }

}

// Displays histogram from file argument
void displayHistogram(ifstream& myFile) {
    string myText;
    int i = 0;
    int formatWidth = 20;
	
	displayBanner("Histogram Of All Items");

	// Prints out histogram from file lines
    while (myFile >> myText) {
        if (i % 2 == 0) {
            cout << setw(formatWidth) << myText;
        }
        else {
            nCharString('*', stoi(myText));
            cout << endl;
        }
        i++;
    }
}

// Opens file for histogram to be created
void openHistogram() {
    ifstream myFile;

    myFile.open("CS_210_Input_File.dat");

    if (myFile.is_open()) {
		displayHistogram(myFile);
    }
    else {
        cout << "File could not be opened" << endl;
    }

    myFile.close();
}

// Processes item counter information
void displayItemCounter() {
	string userItem;

	cout << "Please enter item to count: " << endl;
	userItem = validateUserString();

	displayBanner("Item Counter");

	// Displays Item Counted by communicating with Python
	cout << userItem << ": " << callIntFunc("CalculateItemCount", userItem) << endl;
	cout << setfill(' ');
}

// Used to display banner for all items option and calls function to communicate with Python
void displayAllItems() {
	displayBanner("All Items For Store");
	callProcedure("DisplayItemCounts");
}

// Waits for user to press enter key before continuing; this is needed for user to see the information before screen is cleared
void wait() {
	cout << "\nPress enter to continue..." << endl;
	cin.ignore();
	cin.get();
}

int main()
{
	// cout << "\033[2J\033[1;1H"; <- This clears the screen

    string userItem;
    int userInput = 0;

    while (userInput != 4) {
		cout << "\033[2J\033[1;1H";
        displayMenu();
        userInput = validateUserInt();

        switch (userInput) {
			case 1:
				cout << "\033[2J\033[1;1H";
				displayAllItems();
				wait();
				break;
			case 2:
				cout << "\033[2J\033[1;1H";
				displayItemCounter();
				wait();
				break;
			case 3:
				cout << "\033[2J\033[1;1H";
				callProcedure("CreateFile");
				openHistogram();
				wait();
				break;
			case 4:
				cout << "\033[2J\033[1;1H";
				cout << "Quitting Program..." << endl;
				break;
			default:
				cout << "\033[2J\033[1;1H";
				cout << "Error! Option not available" << endl;
				wait();
				break;
        }
    }

    return 0;

}